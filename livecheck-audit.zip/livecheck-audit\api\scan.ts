import { createClient } from '@supabase/supabase-js';
import { scanWebsite, calculateScore } from './scanner.js';
import { verifySession, corsHeaders, jsonError } from './_auth.js';
import { checkRateLimit, rateLimitHeaders, getClientIP } from './_ratelimit.js';

const supabaseUrl = process.env.SUPABASE_URL || process.env.VITE_SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

if (!supabaseUrl || !supabaseKey) {
  console.error('Missing SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY');
}

const supabase = supabaseUrl && supabaseKey ? createClient(supabaseUrl, supabaseKey) : null;

export default async function handler(req: Request): Promise<Response> {
  const headers = corsHeaders();

  if (req.method === 'OPTIONS') {
    return new Response(null, { status: 204, headers });
  }

  if (req.method !== 'POST') {
    return jsonError('Method not allowed', 405, headers);
  }

  const session = await verifySession(req);
  if (!session) {
    return jsonError('Unauthorized', 401, headers);
  }

  const ip = getClientIP(req);
  const rl = checkRateLimit(ip, 'scan', { windowMs: 60_000, maxRequests: 5 });
  if (!rl.allowed) {
    return jsonError('Too many scan requests, try again later', 429, { ...headers, ...rateLimitHeaders(rl) });
  }

  try {
    const body = await req.json();
    const { url, clientName, clientEmail, builderTool, agencyNotes, knownIssues } = body;

    if (!url || !clientName || !clientEmail) {
      return jsonError('Missing required fields: url, clientName, clientEmail', 400, headers);
    }

    let normalizedUrl = url.trim();
    if (!normalizedUrl.startsWith('http')) normalizedUrl = 'https://' + normalizedUrl;

    try {
      new URL(normalizedUrl);
    } catch {
      return jsonError('Invalid URL format', 400, headers);
    }

    const scanResult = await scanWebsite(normalizedUrl);
    const score = calculateScore(scanResult);

    const projectId = `lc-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 6)}`;

    const project = {
      id: projectId,
      user_id: session.sub,
      site_url: normalizedUrl,
      client_name: clientName,
      client_email: clientEmail,
      builder_tool: builderTool || 'Unknown',
      agency_notes: agencyNotes || null,
      status: 'scanned',
      complexity_score: score,
      scan_result: scanResult,
      known_issues: knownIssues || [],
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };

    if (supabase) {
      const { error } = await supabase.from('projects').insert(project);
      if (error) {
        console.error('Supabase insert error:', error);
      }
    }

    return new Response(JSON.stringify({
      projectId,
      score,
      scanResult,
      message: 'Scan complete',
    }), {
      status: 200,
      headers: { 'Content-Type': 'application/json', ...headers },
    });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Unknown error';
    console.error('Scan error:', err);
    return jsonError('Scan failed: ' + message, 500, headers);
  }
}
